package expansion;

import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        Scanner mainInput = new Scanner(System.in);
        int backToMenuOption = 0;

        for (int i = 0; i < args.length; i++) {
            System.out.println(args[i]);
        }
         
        try {

            do {
                System.out.println("\n\nDigite o idioma da aplicacao (Para portugues, digite 1, para ingles digite 0)\n\nChoose the app language (for Portuguese, type 1, for english, type 0) ");
                Print.langChoice = mainInput.nextInt();
            } while (!Validate.twoOptions(1, 0, Print.langChoice));

            if (Print.langChoice == 0) {
                Print.en();
            } else {
                Print.pt();
            }

            do {
                System.out.println(Print.textView[0]);
                System.out.println(Print.textView[1]);
                int option = mainInput.nextInt();
    
                switch (option) {
                    case 1: Data.add(); break;
                    case 2: Data.del(); break;
                    case 3: Data.list(); break;
                    case 4: Compute.getInfo(); break;
                    default: System.out.println(Print.textView[2]); break;
                }
                do {
                    System.out.println(Print.textView[3]);            
                    backToMenuOption = mainInput.nextInt();
                } while (!Validate.twoOptions(1, 0, backToMenuOption));
           
            } while (backToMenuOption == 1);
            
            System.out.println(Print.textView[4]); 

            mainInput.close(); Compute.calcInput.close(); 

            
        } catch (Exception e) {
            System.out.println(Print.textView[5]);
        }                             
        
    }

}